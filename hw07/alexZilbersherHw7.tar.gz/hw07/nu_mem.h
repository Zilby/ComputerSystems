#ifndef NU_MEM_H
#define NU_MEM_H

void* nu_malloc(size_t size);
void  nu_free(void* ptr);

#endif
