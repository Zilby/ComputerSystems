#ifndef TRAND_H
#define TRAND_H

void trand_seed(int64_t ss);
int32_t trand();
int32_t trand_range(int32_t bot, int32_t top);

#endif
